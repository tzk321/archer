# 弓箭手大作战 · Godot v2

Godot 4.7.2 手搓复刻，横屏 1280×720，纯几何绘制、无外部美术素材。

## 操作

- 手机：按住屏幕任意位置拖动 = 摇杆；右下「冲」= 冲刺；右上 `$` = 商店；`II` = 暂停
- 电脑：WASD / 方向键移动，空格冲刺，B 商店，P 暂停，1/2/3 选升级
- 自动瞄准最近敌人，自动射击

## v2 内容

- 24 个局内技能：攻击/攻速/多重箭/穿透/暴击/爆伤/移速/生命/回复/磁铁/弹射/
  减伤/护盾/荆棘/金币/经验/爆炸/冰/毒/闪电链/战狼/吸血/复活/冲刺冷却
- 20 把武器：短弓、长弓、连弩、三叉、穿云、弹射、爆炸、冰、火、毒、闪电、
  追踪、回旋镖、霰弹、狙击、双持、月光、太阳、虚空、荆棘
- 20 个关卡：不同配色/障碍/地形区（岩浆、毒沼、冰面、加速带、治疗区、虚空）/
  天气（雨雪沙尘火星雾）/敌人修正/黑暗
- 20 套皮肤：配色 + 兜帽/犄角/头盔/光环/王冠/兽耳/触角/翅膀/尾巴/火焰/面罩
- 20 个特效：命中 10、击杀 5、升级 3、弹道拖尾 2，均可切换
- 局内金币 + 技能商店：每 3 波自动开，5 个技能位，刷新 3 金；金币结算按 50% 转局外
- 局外金币解锁武器/皮肤/特效，存 `user://settings.cfg`
- 玩法机制：每 5 波词缀（狂暴/分裂/护盾/毒雾/财宝）、随机事件（商队/血月/补给/
  精英狩猎/流星雨）、精英词缀（迅捷/分裂/吸血/护盾/巨大）、连击倍率、冲刺、
  BOSS 轮换（精英怪/巫妖/巨兽/虚空领主）
- 难度：基础 150 血、25% 受伤减免、0.8 秒无敌、敌人上限 32、BOSS 75 秒首刷
- 音效：运行时生成 WAV（射击/命中/受伤/击杀/升级/拾取/购买/死亡/弹幕）

## 数据驱动

```
data/skills.gd    24
data/weapons.gd   20
data/levels.gd    20
data/skins.gd     20
data/effects.gd   20
```

`--test` 启动日志会打印：

```
CONTENT skills=24 weapons=20 levels=20 skins=20 effects=20
```

## 构建

```sh
export XDG_CONFIG_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/config
export XDG_DATA_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/data
export ANDROID_USER_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/android-user
G=/home/sbtzk/jobs/godot-chair-riot/tools/godot/Godot_v4.7.2-stable_linux.x86_64
$G --headless --editor --import --quit
$G --headless --path . --export-release Windows
$G --headless --path . --export-debug Android
```

输出：`dist/windows/ArcherGodot.exe`、`dist/android/ArcherGodot.apk`
包名：`top.tzk.archergodot`（debug 签名，`pm install -r` 覆盖安装）

## 测试

```sh
$G --headless --fixed-fps 60 --path . -- --test
$G --headless --fixed-fps 60 --path . -- --test --long   # 200 秒
```

`--test` 自动开局、自动走位/拾取/选卡/购物，100 秒（`--long` 200 秒）后打印
`TEST_SUMMARY` 与 `TEST_DONE`。基线：200 秒自动存活，Lv.16，2 个 BOSS。

## 已知取舍

- 皮肤/特效/武器是局外解锁，局内不改变数值（武器改弹道，皮肤只改外观）。
- 关卡是程序化主题 + 参数变体，不是 20 张手绘地图。
- 字体是 Noto Sans CJK SC 子集（549 字，218 KB），改文案后需要重新生成。
- 无外置音频文件，音效运行时生成，Web 端未适配。
