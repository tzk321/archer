extends RefCounted

## 20 个关卡：配色 + 障碍 + 地形区 + 天气 + 敌人修正。
## obs: none/trees/rocks/crystals/pillars
## zones: lava/poison/ice/haste/heal/void，每个字符串生成一个区域
## weather: none/rain/snow/sand/embers/fog
## mod: none/armored/swift/horde/spooky/void/elite

const LIST := [
	{ "id": "starfield", "n": "星野",     "bg": "#0b0e17", "grid": "#141b2e", "accent": "#54e6c0", "obs": "none",     "zones": [],                       "weather": "none",   "mod": "none",    "dark": false },
	{ "id": "wasteland", "n": "荒原",     "bg": "#171008", "grid": "#2a1d0f", "accent": "#d9a066", "obs": "rocks",    "zones": [],                       "weather": "none",   "mod": "none",    "dark": false },
	{ "id": "snowfield", "n": "雪原",     "bg": "#0d1620", "grid": "#1b2b3a", "accent": "#9fd0ff", "obs": "none",     "zones": ["ice", "ice", "ice"],    "weather": "snow",   "mod": "swift",   "dark": false },
	{ "id": "volcano",   "n": "熔岩",     "bg": "#170b0b", "grid": "#2a1414", "accent": "#ff6b35", "obs": "rocks",    "zones": ["lava", "lava", "lava"], "weather": "embers", "mod": "armored", "dark": false },
	{ "id": "swamp",     "n": "毒沼",     "bg": "#0d160f", "grid": "#1a2a1c", "accent": "#78d17a", "obs": "trees",    "zones": ["poison", "poison"],     "weather": "rain",   "mod": "none",    "dark": false },
	{ "id": "forest",    "n": "密林",     "bg": "#0a140d", "grid": "#162a1a", "accent": "#43a047", "obs": "trees",    "zones": [],                       "weather": "none",   "mod": "horde",   "dark": false },
	{ "id": "ruins",     "n": "废墟",     "bg": "#141210", "grid": "#262220", "accent": "#b0a090", "obs": "rocks",    "zones": [],                       "weather": "fog",    "mod": "armored", "dark": false },
	{ "id": "desert",    "n": "沙漠",     "bg": "#1a1408", "grid": "#2c2410", "accent": "#f2c94c", "obs": "pillars",  "zones": ["haste"],                "weather": "sand",   "mod": "swift",   "dark": false },
	{ "id": "icelake",   "n": "冰湖",     "bg": "#0a1520", "grid": "#16283a", "accent": "#cfeaff", "obs": "none",     "zones": ["ice", "ice", "ice", "ice"], "weather": "snow", "mod": "none", "dark": false },
	{ "id": "thunder",   "n": "雷丘",     "bg": "#12101c", "grid": "#221d33", "accent": "#b197fc", "obs": "pillars",  "zones": [],                       "weather": "rain",   "mod": "spooky",  "dark": false },
	{ "id": "dungeon",   "n": "地牢",     "bg": "#08080c", "grid": "#15151d", "accent": "#7f8fa6", "obs": "rocks",    "zones": [],                       "weather": "fog",    "mod": "armored", "dark": true },
	{ "id": "sanctum",   "n": "圣坛",     "bg": "#0f1418", "grid": "#1c262c", "accent": "#ffe08a", "obs": "pillars",  "zones": ["heal", "heal"],         "weather": "none",   "mod": "none",    "dark": false },
	{ "id": "caldera",   "n": "火山口",   "bg": "#1a0a06", "grid": "#2c140c", "accent": "#ff5d3a", "obs": "rocks",    "zones": ["lava", "lava", "lava", "lava"], "weather": "embers", "mod": "elite", "dark": false },
	{ "id": "crystal",   "n": "水晶洞",   "bg": "#0b1418", "grid": "#172a30", "accent": "#6fe3ff", "obs": "crystals", "zones": ["haste"],                "weather": "none",   "mod": "none",    "dark": false },
	{ "id": "ghost",     "n": "幽灵领域", "bg": "#0c0c14", "grid": "#1a1a26", "accent": "#c0a0ff", "obs": "none",     "zones": [],                       "weather": "fog",    "mod": "spooky",  "dark": true },
	{ "id": "mire",      "n": "腐沼",     "bg": "#0c120c", "grid": "#182418", "accent": "#8ab86a", "obs": "trees",    "zones": ["poison", "poison", "ice"], "weather": "fog", "mod": "horde",   "dark": false },
	{ "id": "fortress",  "n": "钢铁要塞", "bg": "#101216", "grid": "#20242c", "accent": "#9aa7b8", "obs": "pillars",  "zones": [],                       "weather": "none",   "mod": "armored", "dark": false },
	{ "id": "windway",   "n": "风道",     "bg": "#0a1218", "grid": "#162430", "accent": "#7ee0c0", "obs": "crystals", "zones": ["haste", "haste"],       "weather": "sand",   "mod": "swift",   "dark": false },
	{ "id": "void",      "n": "虚空",     "bg": "#0b0812", "grid": "#1c1430", "accent": "#b388ff", "obs": "none",     "zones": ["void", "void"],         "weather": "none",   "mod": "void",    "dark": true },
	{ "id": "throne",    "n": "王座",     "bg": "#12080c", "grid": "#260f16", "accent": "#ff4d6d", "obs": "pillars",  "zones": ["lava"],                 "weather": "embers", "mod": "elite",   "dark": false },
]

static func find(id: String) -> Dictionary:
	for l in LIST:
		if l.id == id:
			return l
	return LIST[0]
