extends RefCounted

## 20 把武器：决定基础伤害/攻速/箭数/弹道，技能在其上叠乘。
## special: none / explode / frost / poison / chain / burn / homing / boomerang / execute / thorn / moon

const LIST := [
	{ "id": "shortbow", "n": "短弓",     "d": "最顺手的基础弓",            "dmg": 1.00, "rate": 0.40, "arrows": 1, "spread": 0.10, "speed": 820,  "pierce": 0, "bounce": 0, "life": 1.15, "color": "#d9a066", "special": "none",      "cost": 0 },
	{ "id": "longbow",  "n": "长弓",     "d": "高伤慢射，穿透 1",          "dmg": 1.55, "rate": 0.62, "arrows": 1, "spread": 0.08, "speed": 1050, "pierce": 1, "bounce": 0, "life": 1.20, "color": "#e6c288", "special": "none",      "cost": 40 },
	{ "id": "repeater", "n": "连弩",     "d": "低伤高频，泼水一样",        "dmg": 0.55, "rate": 0.19, "arrows": 1, "spread": 0.09, "speed": 900,  "pierce": 0, "bounce": 0, "life": 1.00, "color": "#9fd0ff", "special": "none",      "cost": 60 },
	{ "id": "triple",   "n": "三叉弓",   "d": "一次三箭扇形",             "dmg": 0.80, "rate": 0.48, "arrows": 3, "spread": 0.26, "speed": 850,  "pierce": 0, "bounce": 0, "life": 1.05, "color": "#7ee0c0", "special": "none",      "cost": 80 },
	{ "id": "piercer",  "n": "穿云弓",   "d": "高速穿透 4 个",            "dmg": 1.10, "rate": 0.55, "arrows": 1, "spread": 0.05, "speed": 1500, "pierce": 4, "bounce": 0, "life": 1.10, "color": "#ffe08a", "special": "none",      "cost": 90 },
	{ "id": "ricochet", "n": "弹射弓",   "d": "命中后弹 3 次",            "dmg": 0.90, "rate": 0.45, "arrows": 1, "spread": 0.08, "speed": 880,  "pierce": 0, "bounce": 3, "life": 1.30, "color": "#ffb3c1", "special": "none",      "cost": 90 },
	{ "id": "bomber",   "n": "爆炸弓",   "d": "命中炸开一片",             "dmg": 1.15, "rate": 0.62, "arrows": 1, "spread": 0.10, "speed": 760,  "pierce": 0, "bounce": 0, "life": 1.15, "color": "#ff8a5c", "special": "explode",   "cost": 120 },
	{ "id": "frostbow", "n": "冰弓",     "d": "命中减速 45%",             "dmg": 0.95, "rate": 0.45, "arrows": 1, "spread": 0.10, "speed": 860,  "pierce": 0, "bounce": 0, "life": 1.15, "color": "#8fd8ff", "special": "frost",     "cost": 110 },
	{ "id": "flamebow", "n": "火弓",     "d": "命中点燃持续掉血",          "dmg": 0.90, "rate": 0.38, "arrows": 1, "spread": 0.10, "speed": 900,  "pierce": 0, "bounce": 0, "life": 1.10, "color": "#ff6b35", "special": "burn",      "cost": 110 },
	{ "id": "venom",    "n": "毒弓",     "d": "命中叠毒",                "dmg": 0.80, "rate": 0.42, "arrows": 1, "spread": 0.10, "speed": 840,  "pierce": 0, "bounce": 0, "life": 1.15, "color": "#78d17a", "special": "poison",    "cost": 100 },
	{ "id": "storm",    "n": "闪电弓",   "d": "命中后闪电连锁 2 次",      "dmg": 0.85, "rate": 0.42, "arrows": 1, "spread": 0.10, "speed": 980,  "pierce": 0, "bounce": 0, "life": 1.05, "color": "#b197fc", "special": "chain",     "cost": 130 },
	{ "id": "seeker",   "n": "追踪弓",   "d": "箭矢会拐弯追人",           "dmg": 0.80, "rate": 0.48, "arrows": 1, "spread": 0.12, "speed": 700,  "pierce": 0, "bounce": 0, "life": 1.60, "color": "#6fe3ff", "special": "homing",    "cost": 140 },
	{ "id": "boomer",   "n": "回旋镖",   "d": "飞出去还会飞回来",          "dmg": 0.90, "rate": 0.55, "arrows": 1, "spread": 0.06, "speed": 900,  "pierce": 0, "bounce": 0, "life": 1.40, "color": "#f2c94c", "special": "boomerang", "cost": 120 },
	{ "id": "shotgun",  "n": "霰弹弓",   "d": "五箭贴脸爆发",             "dmg": 0.38, "rate": 0.60, "arrows": 5, "spread": 0.18, "speed": 980,  "pierce": 0, "bounce": 0, "life": 0.38, "color": "#ffd166", "special": "none",      "cost": 110 },
	{ "id": "sniper",   "n": "狙击弓",   "d": "超远单发重箭",             "dmg": 2.60, "rate": 0.95, "arrows": 1, "spread": 0.02, "speed": 1900, "pierce": 2, "bounce": 0, "life": 1.40, "color": "#c9d8ee", "special": "none",      "cost": 150 },
	{ "id": "dual",     "n": "双持弓",   "d": "一次两箭平行",             "dmg": 0.70, "rate": 0.30, "arrows": 2, "spread": 0.10, "speed": 900,  "pierce": 0, "bounce": 0, "life": 1.05, "color": "#f0a6ff", "special": "none",      "cost": 100 },
	{ "id": "moonbow",  "n": "月光弓",   "d": "暴击 +15%，银色箭",        "dmg": 1.00, "rate": 0.42, "arrows": 1, "spread": 0.08, "speed": 900,  "pierce": 0, "bounce": 0, "life": 1.20, "color": "#dbeaff", "special": "moon",      "cost": 160 },
	{ "id": "sunbow",   "n": "太阳弓",   "d": "小爆炸 + 点燃",            "dmg": 1.25, "rate": 0.55, "arrows": 1, "spread": 0.10, "speed": 860,  "pierce": 0, "bounce": 0, "life": 1.15, "color": "#ffca3a", "special": "explode",   "cost": 160 },
	{ "id": "voidbow",  "n": "虚空弓",   "d": "穿透 3，残血直接抹除",      "dmg": 1.00, "rate": 0.46, "arrows": 1, "spread": 0.08, "speed": 950,  "pierce": 3, "bounce": 0, "life": 1.20, "color": "#b388ff", "special": "execute",   "cost": 180 },
	{ "id": "thornbow", "n": "荆棘弓",   "d": "小爆炸，反弹近身伤害",      "dmg": 0.85, "rate": 0.40, "arrows": 1, "spread": 0.10, "speed": 880,  "pierce": 0, "bounce": 0, "life": 1.10, "color": "#8ab86a", "special": "thorn",     "cost": 140 },
]

static func find(id: String) -> Dictionary:
	for w in LIST:
		if w.id == id:
			return w
	return LIST[0]
