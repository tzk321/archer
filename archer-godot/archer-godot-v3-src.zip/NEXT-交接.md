# 交接：弓箭手大作战 · Godot v3

日期：2026-10-19
上一版：v2（横屏、20+ 内容、商店技能）
本版：v3（职业、近战、传说技能、图标、后期难度）

---

## 0. 交付物

```
WSL: /home/sbtzk/games/archer-godot          # v3 工程
WSL: /home/sbtzk/games/archer-godot-v1       # v1 备份
手机: /sdcard/Download/ArcherGodot.apk       # v3，versionCode=3 / 3.0.0
手机: /sdcard/Download/ArcherGodot-win64.exe
手机: /sdcard/Download/archer-godot-v3-src.zip
手机: /sdcard/Download/archer-godot-v3-handoff.zip
```

---

## 1. v3 按你的要求改了什么

### 1.1 后期不再白给

- 敌人数值从第 6 波后额外成长：`pow(wave-6,1.45)*0.10` 血量、`pow(wave-8,1.3)*0.8` 伤害、速度随波次增加
- 第 8 波后敌人上限 32 → 42；第 12 波起每 3 波多刷一只精英
- BOSS 血量随 BOSS 序号额外成长
- 三档难度：**休闲 0.75 血/0.7 伤害，标准 1.0，噩梦 1.35 血/1.3 伤害**；默认标准，大厅可点
- 标准难度 200 秒自动测试：`t=197.7 hp=64 lv=15 kills=278 bosses=2 minHP=3`，已经不是站撸
- 觉醒词条（力量/生命/疾速/暴击）最高 20 层，商店专属，满级后继续买

### 1.2 商店更有购买欲

- 商店 6 格，至少 1 个**传说自动技**，技能 + 传说混卖
- 10 个传说技能：陨石术、雷霆风暴、黑洞、时间暂停、巨龙、分身、
  冰霜新星、火焰风暴、守护天使、血月
- 传说价格 60–100 金，买了自动施放，陨石/黑洞/巨龙/分身都有独立绘制
- 4 个觉醒词条可叠 10–20 层，解决“技能买满后商店没东西买”
- 刷新 3 金；BOSS/精英/词缀波金币产出提高

### 1.3 近战武器

新增 12 把近战/职业武器，总武器 32 把：

```
铁剑 / 巨斧 / 长枪 / 双匕 / 战锤 / 镰刀 / 拳套 / 光剑 / 毒牙 / 雷锤
火焰法杖 / 灵弓（职业远程）
```

机制：挥砍弧、击退、直线突刺、三连拳、砸地 AoE、360 回旋、点燃、中毒、闪电链。

### 1.4 多职业

6 个职业，大厅「职业」页选择：

| 职业 | 初始武器 | 血量 | 移速 | 伤害 | 护甲 | 自带技能 |
|---|---|---|---|---|---|---|
| 游侠 | 短弓 | 150 | 255 | +0% | +25% | 无 |
| 剑士 | 铁剑（近战） | 190 | 245 | +10% | +30% | 荆棘 Lv.1 |
| 法师 | 火焰法杖 | 130 | 245 | +15% | +15% | 爆炸箭 Lv.1 |
| 刺客 | 双匕（近战） | 140 | 275 | -5% | +18% | 疾冲 Lv.1 |
| 狂战士 | 巨斧（近战） | 210 | 235 | +20% | +25% | 吸血 Lv.1 |
| 召唤师 | 灵弓 | 150 | 245 | -10% | +25% | 战狼 Lv.1 |

选择职业会自动解锁并使用该职业的初始武器。

### 1.5 每个技能/武器都有图

- 28 个技能：`_draw_skill_icon(id, pos, s)` 全部独立几何图标（心、盾、雪花、闪电、狼头、硬币、符文等）
- 32 把武器：`_draw_weapon_icon(w, pos, s)`，剑/斧/枪/匕首/锤/镰/拳/光剑/法杖/弓 + 特殊徽章
- 10 个传说：`_draw_ult_icon(id, pos, s)`，陨石/雷云/黑洞/时钟/龙/分身/雪花/火焰/天使盾/血月
- 6 个职业：职业色头像 + 初始武器图标
- 图标出现在：升级三选一、商店 6 格、武器图鉴、职业页

---

## 2. 工程结构

```
project.godot            # 1280×720 横屏，v3.0.0
main.tscn
game.gd                  # 主逻辑 + UI + 图标绘制 + 传说技能
data/skills.gd           # 28 技能（含 4 觉醒）
data/weapons.gd          # 32 武器（含 12 近战/职业）
data/levels.gd           # 20 关卡
data/skins.gd            # 20 皮肤
data/effects.gd          # 20 特效
data/classes.gd          # 6 职业
data/ultimates.gd        # 10 传说
font.ttf                 # Noto Sans CJK SC 子集（638 字，249 KB）
export_presets.cfg       # versionCode=3 / 3.0.0
dist/windows/ArcherGodot.exe
dist/android/ArcherGodot.apk
dist/archer-godot-v3-src.zip
```

---

## 3. 测试证据

```text
CONTENT skills=28 weapons=32 levels=20 skins=20 effects=20 classes=6 ultimates=10

标准难度 200 秒（Ranger）:
TEST_SUMMARY t=197.7 hp=64 lv=15 kills=278 gold=544 best_combo=85 bosses=2
minHP=3，CAST_ULT=6，TEST_DONE，0 条 SCRIPT ERROR

100 秒职业抽测:
mage      t=98.7 hp=130 lv=9 kills=113 bosses=1 casts=10
summoner  t=98.9 hp=74  lv=8 kills=98  bosses=1 casts=0
assassin  t=98.8 hp=140 lv=8 kills=100 bosses=1 casts=9
blade     t=98.7 hp=187 lv=9 kills=107 bosses=1
```

手机实机（v3 安装后）：

- versionCode=3 / versionName=3.0.0，横屏 Activity 2400×1080
- 启动正常，职业页显示 6 职业/初始武器/自带技能；所有卡片有职业头像和武器图标
- 选中「剑士」后开局 190/190 血，近战铁剑击杀正常；30 秒 Lv.3、16 杀，第二关「荒原」
- 技能商店出现 6 格：传说「火焰风暴 · 自动施放」+「暴击觉醒」，价格/等级/购买按钮正常
- 武器图鉴显示 32 把（含铁剑/巨斧/长枪/双匕/战锤/镰刀/拳套/光剑/毒牙/雷锤），每把带图标
- 皮肤页、特效页、购买/切换、中文渲染正常
- 截图：`/sdcard/Download/archer-v3-shop.png`、`/sdcard/Download/archer-v3-weapons.png`

---

## 4. 构建 / 安装

同 v2。导出：

```sh
export XDG_CONFIG_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/config
export XDG_DATA_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/data
export ANDROID_USER_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/android-user
G=/home/sbtzk/jobs/godot-chair-riot/tools/godot/Godot_v4.7.2-stable_linux.x86_64
$G --headless --path . --editor --import --quit
$G --headless --path . --export-release Windows
$G --headless --path . --export-debug Android
```

安装：

```sh
su -c 'cp /sdcard/Download/ArcherGodot.apk /data/local/tmp/ArcherGodot.apk && chmod 644 /data/local/tmp/ArcherGodot.apk && pm install -r /data/local/tmp/ArcherGodot.apk'
```

---

## 5. 已知坑 / 待办

1. 字体子集 638 字；改中文文案后必须重新生成（源 TTC face 2）。
2. 近战自动瞄准只追到 80px 外，手操体验更好；测试脚本能活 100 秒。
3. 传说技能是自动施放，没有手动大招键；以后要加可以挂在冲刺键长按。
4. 职业图标是几何头像，不是立绘；要换真图需外置素材。
5. 商店 6 格在 1280×720 下刚好；再加内容建议做分页/滚动。
