# 交接：弓箭手大作战 · Godot v3.1

日期：2026-10-19
上一版：v3（职业/近战/传说/图标）
本版：v3.1（职业武器池分离、职业技能池分离、初始技能对齐、45 武器）

---

## 0. 交付物

```
WSL: /home/sbtzk/games/archer-godot          # v3.1 工程
WSL: /home/sbtzk/games/archer-godot-v1       # v1 备份
手机: /sdcard/Download/ArcherGodot.apk       # v3.1，versionCode=4 / 3.1.0
手机: /sdcard/Download/ArcherGodot-win64.exe
手机: /sdcard/Download/archer-godot-v3.1-src.zip
手机: /sdcard/Download/archer-godot-v3.1-handoff.zip
```

---

## 1. v3.1 按你的原话改了什么

> “我职业对应的武器分开做，技能也对不上”

### 1.1 职业武器池分开

每个职业只显示/只能装备自己的武器，图鉴标题写「XX专属」：

| 职业 | 专属武器 | 数量 |
|---|---|---|
| 游侠 | 短弓/长弓/连弩/三叉/穿云/弹射/回旋镖/霰弹/狙击/双持/月光/太阳/虚空/荆棘 | 14 |
| 剑士 | 铁剑/长剑/巨剑/光剑/长枪 | 5 |
| 法师 | 火焰法杖/冰法杖/雷法杖/暗法杖/秘法书 | 5 |
| 刺客 | 双匕/影刃/毒牙/拳套/飞刀 | 5 |
| 狂战士 | 巨斧/双斧/巨锤/战锤/雷锤/镰刀 | 6 |
| 召唤师 | 灵弓/骨杖/兽杖/魂铃 | 4 |

- 选职业会自动切换成该职业初始武器并解锁
- `meta.weapon` 若不属于当前职业，读档时自动回退到职业初始武器
- 武器图鉴只列出当前职业的武器，`--test` 打印 `weapons=45`（总库 45）

### 1.2 职业技能池分开

每个职业只刷自己的技能，不会出现“剑士刷战狼、法师刷荆棘”：

| 职业 | 技能池（核心） | 初始技能 |
|---|---|---|
| 游侠 | 攻/速/多重/穿透/暴击/爆伤/移速/磁铁/弹射/悟性/冰/毒/闪电链/财迷/生命 | 多重箭 Lv.1 |
| 剑士 | 攻/生命/铁皮/回复/护盾/荆棘/吸血/不屈/疾冲/移速/暴击/爆伤/爆炸 | 铁皮 Lv.1 |
| 法师 | 攻/速/多重/穿透/暴击/爆伤/爆炸/冰/毒/闪电链/悟性/磁铁/财迷/生命 | 爆炸箭 Lv.1 |
| 刺客 | 攻/速/暴击/爆伤/移速/疾冲/多重/穿透/弹射/吸血/财迷/磁铁/生命 | 疾冲 Lv.1 |
| 狂战士 | 攻/速/生命/铁皮/回复/吸血/荆棘/爆炸/爆伤/移速/护盾/疾冲 | 吸血 Lv.1 |
| 召唤师 | 攻/速/生命/回复/战狼/悟性/磁铁/财迷/冰/毒/闪电链/吸血/护盾/疾冲 | 战狼 Lv.1 |

- 升级三选一只从本职业池抽
- 商店技能也按职业过滤；觉醒词条和 10 个传说对所有职业开放
- 初始技能直接送 1 级，职业页会写「自带技能：XXX Lv.1」

### 1.3 图标

- 28 技能全图标；45 武器全图标（新增长剑/巨剑/影刃/飞刀/双斧/巨锤/四系法杖/秘法书/骨杖/兽杖/魂铃）
- 10 传说全图标；6 职业头像 + 初始武器图标
- 升级卡 / 商店 6 格 / 武器图鉴 / 职业页都带图

### 1.4 其他保留

- 10 个传说自动技：陨石/雷霆风暴/黑洞/时间暂停/巨龙/分身/冰霜新星/火焰风暴/守护天使/血月
- 三档难度：休闲/标准/噩梦，默认标准
- 后期波次成长：第 6 波后血量/伤害/速度额外成长，第 12 波起每 3 波多精英
- 觉醒词条：力量/生命/疾速/暴击，最高 10–20 层，商店专属

---

## 2. 工程结构

```
project.godot            # 1280×720 横屏，v3.1
main.tscn
game.gd                  # 主逻辑 + UI + 图标 + 传说
data/skills.gd           # 28 技能 + CLASS_SKILLS
data/weapons.gd          # 45 武器 + CLASS_WEAPONS
data/levels.gd           # 20 关卡
data/skins.gd            # 20 皮肤
data/effects.gd          # 20 特效
data/classes.gd          # 6 职业
data/ultimates.gd        # 10 传说
font.ttf                 # Noto Sans CJK SC 子集（648 字，253 KB）
export_presets.cfg       # versionCode=4 / 3.1.0
dist/windows/ArcherGodot.exe
dist/android/ArcherGodot.apk
```

---

## 3. 测试证据

```text
CONTENT skills=28 weapons=45 levels=20 skins=20 effects=20 classes=6 ultimates=10

标准 200s 游侠：t=197.4 hp=151 lv=17 kills=355 gold=909 best_combo=290 bosses=2
100s 法师：t=99.0 hp=71 lv=7 kills=109 bosses=1
100s 剑士：t=98.8 hp=190 lv=8 kills=100 bosses=1
100s 最终包：t=98.7 hp=150 lv=9 kills=113 bosses=1
```

- 0 条 `SCRIPT ERROR|ERROR:`
- 渲染验证：职业页 6 职业、游侠图鉴 14 把、法师图鉴 5 把、商店 6 格（传说+觉醒）、升级卡带图标
- 手机：v3.1 已安装（versionCode=4 / 3.1.0），大厅显示「6 职业 45 武器 10 传说」

---

## 4. 构建 / 安装

```sh
export XDG_CONFIG_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/config
export XDG_DATA_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/data
export ANDROID_USER_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/android-user
G=/home/sbtzk/jobs/godot-chair-riot/tools/godot/Godot_v4.7.2-stable_linux.x86_64
$G --headless --path . --editor --import --quit
$G --headless --path . --export-release Windows
$G --headless --path . --export-debug Android
```

安装：

```sh
su -c 'cp /sdcard/Download/ArcherGodot.apk /data/local/tmp/ArcherGodot.apk && chmod 644 /data/local/tmp/ArcherGodot.apk && pm install -r /data/local/tmp/ArcherGodot.apk'
```

---

## 5. 已知坑 / 待办

1. 字体子集 648 字；改中文文案后重新生成（NotoSansCJK TTC face 2）。
2. 职业武器池是硬映射（`weapons.gd CLASS_WEAPONS`）；加武器要同时加映射。
3. 职业技能池 `skills.gd CLASS_SKILLS`；加技能要决定归属职业，或放 `觉醒` 分类做全职业通用。
4. 传说技能全职业通用，后续要做职业专属传说可加 `cls` 字段。
5. 武器图鉴每职业独立，游侠 14 把占 3 行，其他职业 1 行；再加内容建议分页。
