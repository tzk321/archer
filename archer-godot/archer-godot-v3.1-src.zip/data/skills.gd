extends RefCounted

## 24 个可购买/升级技能。apply 逻辑在 game.gd 的 apply_skill()。
## id, 名称, 描述, 最大等级, 基础价格, 分类

const LIST := [
	{ "id": "dmg",      "n": "强力箭",   "d": "攻击力 +25%",            "max": 9, "cost": 8,  "cat": "攻击" },
	{ "id": "rate",     "n": "疾风弓",   "d": "攻速 +15%",              "max": 8, "cost": 9,  "cat": "攻击" },
	{ "id": "multi",    "n": "多重箭",   "d": "每次多射 1 支箭",         "max": 4, "cost": 16, "cat": "攻击" },
	{ "id": "pierce",   "n": "穿透箭",   "d": "箭矢多穿透 1 个敌人",     "max": 3, "cost": 12, "cat": "攻击" },
	{ "id": "crit",     "n": "致命瞄准", "d": "暴击率 +10%",            "max": 5, "cost": 10, "cat": "攻击" },
	{ "id": "critdmg",  "n": "爆头",     "d": "暴击伤害 +40%",          "max": 5, "cost": 10, "cat": "攻击" },
	{ "id": "speed",    "n": "轻步",     "d": "移速 +10%",              "max": 6, "cost": 7,  "cat": "身法" },
	{ "id": "hp",       "n": "强健体魄", "d": "生命上限 +30 并回复",     "max": 9, "cost": 8,  "cat": "防御" },
	{ "id": "regen",    "n": "野性回复", "d": "每秒回复 +0.9 生命",      "max": 5, "cost": 9,  "cat": "防御" },
	{ "id": "magnet",   "n": "贪婪之手", "d": "经验拾取范围 +35%",       "max": 5, "cost": 6,  "cat": "功能" },
	{ "id": "bounce",   "n": "弹射箭",   "d": "箭矢命中后弹向敌人",      "max": 2, "cost": 18, "cat": "攻击" },
	{ "id": "armor",    "n": "铁皮",     "d": "受到伤害 -7%",           "max": 5, "cost": 10, "cat": "防御" },
	{ "id": "shield",   "n": "护盾",     "d": "获得 25 护盾，12 秒回充", "max": 5, "cost": 12, "cat": "防御" },
	{ "id": "thorn",    "n": "荆棘",     "d": "反伤 +15，碰你就掉血",    "max": 5, "cost": 9,  "cat": "防御" },
	{ "id": "greed",    "n": "财迷",     "d": "金币获取 +25%",          "max": 5, "cost": 8,  "cat": "功能" },
	{ "id": "wisdom",   "n": "悟性",     "d": "经验获取 +20%",          "max": 5, "cost": 8,  "cat": "功能" },
	{ "id": "explode",  "n": "爆炸箭",   "d": "命中产生爆炸",           "max": 3, "cost": 18, "cat": "元素" },
	{ "id": "frost",    "n": "冰箭",     "d": "命中减速 45%",           "max": 3, "cost": 16, "cat": "元素" },
	{ "id": "poison",   "n": "毒箭",     "d": "命中持续掉血",           "max": 3, "cost": 16, "cat": "元素" },
	{ "id": "chain",    "n": "闪电链",   "d": "命中后闪电连锁",         "max": 3, "cost": 20, "cat": "元素" },
	{ "id": "wolf",     "n": "战狼",     "d": "召唤一头战狼助战",        "max": 3, "cost": 22, "cat": "召唤" },
	{ "id": "lifesteal","n": "吸血",     "d": "造成伤害的 6% 回血",      "max": 4, "cost": 14, "cat": "特殊" },
	{ "id": "revive",   "n": "不屈",     "d": "死亡后原地复活一次",      "max": 2, "cost": 30, "cat": "特殊" },
	{ "id": "dash",     "n": "疾冲",     "d": "冲刺冷却 -0.7 秒",       "max": 3, "cost": 10, "cat": "身法" },
	{ "id": "awaken_dmg",  "n": "力量觉醒", "d": "攻击力 +15%（可叠 20 层）",   "max": 20, "cost": 30, "cat": "觉醒" },
	{ "id": "awaken_hp",   "n": "生命觉醒", "d": "生命上限 +40（可叠 20 层）",  "max": 20, "cost": 28, "cat": "觉醒" },
	{ "id": "awaken_rate", "n": "疾速觉醒", "d": "攻速 +8%（可叠 12 层）",      "max": 12, "cost": 32, "cat": "觉醒" },
	{ "id": "awaken_crit", "n": "暴击觉醒", "d": "暴击率 +5%（可叠 10 层）",    "max": 10, "cost": 30, "cat": "觉醒" },
]

static func find(id: String) -> Dictionary:
	for s in LIST:
		if s.id == id:
			return s
	return {}

const CLASS_SKILLS := {
	"ranger": ["dmg", "rate", "multi", "pierce", "crit", "critdmg", "speed", "magnet", "bounce", "wisdom", "frost", "poison", "chain", "greed", "hp"],
	"blade": ["dmg", "hp", "armor", "regen", "shield", "thorn", "lifesteal", "revive", "dash", "speed", "crit", "critdmg", "explode"],
	"mage": ["dmg", "rate", "multi", "pierce", "crit", "critdmg", "explode", "frost", "poison", "chain", "wisdom", "magnet", "greed", "hp"],
	"assassin": ["dmg", "rate", "crit", "critdmg", "speed", "dash", "multi", "pierce", "bounce", "lifesteal", "greed", "magnet", "hp"],
	"berserker": ["dmg", "rate", "hp", "armor", "regen", "lifesteal", "thorn", "explode", "critdmg", "speed", "shield", "dash"],
	"summoner": ["dmg", "rate", "hp", "regen", "wolf", "wisdom", "magnet", "greed", "frost", "poison", "chain", "lifesteal", "shield", "dash"],
}

static func for_class(cls: String) -> Array:
	var out: Array = []
	for id in CLASS_SKILLS.get(cls, []):
		var s = find(str(id))
		if not s.is_empty():
			out.append(s)
	return out

static func allowed(cls: String, id: String) -> bool:
	var s = find(id)
	if s.is_empty():
		return false
	if str(s.get("cat", "")) == "觉醒":
		return true
	return id in CLASS_SKILLS.get(cls, [])
