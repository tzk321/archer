# 弓箭手大作战 · Godot v3.1

Godot 4.7.2 手搓复刻，横屏 1280×720，纯几何绘制、无外部美术素材。

## v3 新增

- **6 职业**：游侠 / 剑士 / 法师 / 刺客 / 狂战士 / 召唤师，不同初始武器、属性、自带技能
- **近战武器**：铁剑、巨斧、长枪、双匕、战锤、镰刀、拳套、光剑、毒牙、雷锤，
  以及职业专属长剑/巨剑/影刃/飞刀/双斧/巨锤/冰法杖/雷法杖/暗法杖/秘法书/骨杖/兽杖/魂铃；
  总武器 45 把
- **职业专属池**：每个职业只用自己的武器列表和技能列表（游侠 14 把弓、剑士 5 把剑/枪、
  法师 5 把法杖/书、刺客 5 把匕/飞刀、狂战 6 把斧/锤/镰、召唤 4 把灵弓/法杖/魂铃）
- **商店传说技能 10 个**：陨石术、雷霆风暴、黑洞、时间暂停、巨龙、分身、
  冰霜新星、火焰风暴、守护天使、血月；买了自动施放，特效拉满
- **觉醒词条**：力量 / 生命 / 疾速 / 暴击觉醒可叠 10–20 层，满级后继续变强
- **商店 6 格**：至少 1 个传说，技能 + 传说混卖；刷新 3 金
- **三档难度**：休闲 / 标准 / 噩梦，大厅点击切换；标准以上后期波次成长更陡
- **图标**：28 个技能、32 把武器、10 个传说、6 个职业全部手绘几何图标，
  升级卡 / 商店 / 图鉴 / 职业页都有图

## 操作

- 手机：按住屏幕拖动 = 摇杆；右下「冲」= 冲刺；右上 `$` = 商店；`II` = 暂停
- 电脑：WASD / 方向键，空格冲刺，B 商店，P 暂停，1/2/3 选升级
- 自动瞄准最近敌人；近战武器自动挥砍

## 内容

- 28 技能（24 基础 + 4 觉醒），按职业过滤：剑士不会刷到战狼，法师不会刷到荆棘
- 45 武器（20 远程 + 25 近战/法杖/职业专属）
- 20 关卡：配色/障碍/地形区（岩浆、毒沼、冰面、加速带、治疗、虚空）/天气/黑暗
- 20 皮肤、20 特效
- 5 波词缀 / 5 随机事件 / 5 精英词缀 / 连击 / 冲刺 / BOSS 轮换
- 局内金币 + 局外金币（结算 50% 转化），存 `user://settings.cfg`

## 难度

- 150 血 + 25% 基础减伤 + 0.8s 无敌（游侠）
- 休闲 0.75 血 / 0.7 伤害；标准 1.0；噩梦 1.35 血 / 1.3 伤害
- 第 6 波后敌人血量/伤害/速度额外成长，第 8 波后上限 42 只，第 12 波起每 3 波多一只精英

## 构建

```sh
export XDG_CONFIG_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/config
export XDG_DATA_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/data
export ANDROID_USER_HOME=/home/sbtzk/jobs/godot-chair-riot/tools/android-user
G=/home/sbtzk/jobs/godot-chair-riot/tools/godot/Godot_v4.7.2-stable_linux.x86_64
$G --headless --editor --import --quit
$G --headless --path . --export-release Windows
$G --headless --path . --export-debug Android
```

## 测试

```sh
$G --headless --fixed-fps 60 --path . -- --test
$G --headless --fixed-fps 60 --path . -- --test --long
$G --headless --fixed-fps 60 --path . -- --test --class=blade
$G --headless --fixed-fps 60 --path . -- --test --diff=2
```

`--test` 自动开局/走位/选卡/购物，打印 `CONTENT skills=28 weapons=45 ... classes=6 ultimates=10`。
基线：标准难度 200 秒自动存活（Ranger，Lv.17，2 BOSS，151 血）。

## 已知取舍

- 关卡是程序化主题 + 参数变体，不是 20 张手绘地图。
- 字体 Noto Sans CJK SC 子集（改文案后重新生成）。
- 无外置音频文件，音效运行时生成。
